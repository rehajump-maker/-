/**
 * ============================================================
 * Jump 電子カルテシステム － Google Apps Script バックエンド
 * （ログイン機能・操作ログ 対応版）
 * ============================================================
 *
 * 【このバージョンの変更点】
 * ・スタッフごとのID/パスワードによるログインを追加
 * ・ログイン後に発行される「一時的なセッショントークン」でのみ
 *   データにアクセスできるようになった（以前のように固定の
 *   APIトークンが画面のソースコードに書かれている状態ではない）
 * ・患者情報・カルテの保存/削除などの操作を「操作ログ」シートに記録
 *
 * 【使い方（既存プロジェクトを更新する場合）】
 * 1. このファイルの内容を Code.gs に全て貼り付けて保存
 * 2. 関数「setup」を選び、実行（▶）する
 *    → 「スタッフ」「セッション」「操作ログ」シートが自動生成される
 *    → 実行ログに初期管理者アカウントのID・パスワードが表示される
 *      ので、必ず控えてから「スタッフ」シートで変更してください
 * 3. 「デプロイ」→「デプロイを管理」→ 新しいバージョンで再デプロイ
 * ============================================================
 */

const CONFIG = {
  SPREADSHEET_NAME: "Jump_電子カルテ",
  ROOT_FOLDER_NAME: "Jump_カルテ画像",
  SHEETS: {
    PATIENTS: "患者情報",
    KARTE: "カルテ記録",
    TEMPLATES: "見本テキスト",
    STORES: "店舗",
    STAFF: "スタッフ",
    SESSIONS: "セッション",
    LOGS: "操作ログ",
  },
  SESSION_HOURS: 8, // ログイン状態が続く時間
};

/* ------------------------------------------------------------
 * 初回セットアップ（手動で1回だけ実行）
 * ------------------------------------------------------------ */
function setup() {
  const props = PropertiesService.getScriptProperties();

  let ssId = props.getProperty("SPREADSHEET_ID");
  let ss;
  if (ssId) {
    try { ss = SpreadsheetApp.openById(ssId); } catch (e) { ss = null; }
  }
  if (!ss) {
    ss = SpreadsheetApp.create(CONFIG.SPREADSHEET_NAME);
    props.setProperty("SPREADSHEET_ID", ss.getId());
  }

  ensureSheet(ss, CONFIG.SHEETS.PATIENTS, ["memberId", "name", "birthdate", "store", "notice", "createdAt"]);
  ensureSheet(ss, CONFIG.SHEETS.KARTE, ["entryId", "memberId", "date", "services", "freeService", "text", "images", "createdAt", "updatedAt"]);
  ensureSheet(ss, CONFIG.SHEETS.TEMPLATES, ["templateId", "title", "text"]);
  ensureSheet(ss, CONFIG.SHEETS.STORES, ["storeId", "name"]);
  ensureSheet(ss, CONFIG.SHEETS.STAFF, ["staffId", "name", "username", "password", "role", "active"]);
  ensureSheet(ss, CONFIG.SHEETS.SESSIONS, ["token", "staffId", "name", "role", "expiresAt"]);
  ensureSheet(ss, CONFIG.SHEETS.LOGS, ["logId", "timestamp", "staffId", "staffName", "action", "targetId", "detail"]);

  const defaultSheet = ss.getSheetByName("シート1");
  if (defaultSheet && ss.getSheets().length > 1) ss.deleteSheet(defaultSheet);

  const storeSheet = ss.getSheetByName(CONFIG.SHEETS.STORES);
  if (storeSheet.getLastRow() < 2) {
    storeSheet.appendRow(["store_" + Utilities.getUuid().slice(0, 8), "本店"]);
  }

  const tmplSheet = ss.getSheetByName(CONFIG.SHEETS.TEMPLATES);
  if (tmplSheet.getLastRow() < 2) {
    const defaults = [
      ["腰痛 初回問診", "主訴：腰部の鈍痛あり。日常生活動作（立ち上がり・前屈）で症状増悪。骨盤の歪み・筋緊張を確認し、施術にて可動域改善を図る。次回来店時に経過確認予定。"],
      ["肩こり 定例施術", "主訴：両側肩部〜頸部にかけての張り感。デスクワークによる同一姿勢が影響していると考えられる。肩甲骨周囲の可動域訓練と筋緊張緩和の施術を実施。"],
      ["姿勢分析フォロー", "姿勢分析ツールにて撮影・確認を実施。骨盤の左右差および猫背傾向を本人へ説明。改善エクササイズを提示し、次回撮影にて経過比較予定。"],
      ["パーソナルトレーニング 目標確認", "本日のトレーニング内容を実施。フォーム確認および負荷設定の見直しを行った。次回までの自主トレーニング内容を共有。"],
      ["経過良好", "前回指摘した症状は改善傾向。引き続き同様の施術内容で経過観察とする。"],
    ];
    defaults.forEach(d => tmplSheet.appendRow(["tmpl_" + Utilities.getUuid().slice(0, 8), d[0], d[1]]));
  }

  // 初期管理者アカウント（未作成の場合のみ）
  const staffSheet = ss.getSheetByName(CONFIG.SHEETS.STAFF);
  if (staffSheet.getLastRow() < 2) {
    const initialPassword = "change-me-" + Utilities.getUuid().slice(0, 6);
    staffSheet.appendRow(["staff_" + Utilities.getUuid().slice(0, 8), "管理者", "admin", initialPassword, "admin", true]);
    Logger.log("初期管理者アカウントを作成しました。");
    Logger.log("ユーザー名: admin");
    Logger.log("初期パスワード: " + initialPassword);
    Logger.log("※ 必ず「スタッフ」シートを開いて、このパスワードを分かりやすいものに変更してください。");
  }

  let folderId = props.getProperty("ROOT_FOLDER_ID");
  let folder;
  if (folderId) {
    try { folder = DriveApp.getFolderById(folderId); } catch (e) { folder = null; }
  }
  if (!folder) {
    folder = DriveApp.createFolder(CONFIG.ROOT_FOLDER_NAME);
    props.setProperty("ROOT_FOLDER_ID", folder.getId());
  }

  // 他システム連携用の共有シークレット（未設定の場合のみ発行）
  if (!props.getProperty("LINK_SECRET")) {
    props.setProperty("LINK_SECRET", Utilities.getUuid() + Utilities.getUuid().replace(/-/g, ""));
    Logger.log("連携用シークレットを発行しました。姿勢分析・体力測定システム側にも同じ値を設定してください：");
    Logger.log(props.getProperty("LINK_SECRET"));
  }

  Logger.log("セットアップ完了");
  Logger.log("スプレッドシートURL: " + ss.getUrl());
}

function ensureSheet(ss, name, headers) {
  let sheet = ss.getSheetByName(name);
  if (!sheet) sheet = ss.insertSheet(name);
  if (sheet.getLastRow() === 0) {
    sheet.appendRow(headers);
    sheet.setFrozenRows(1);
  }
  return sheet;
}

/* ------------------------------------------------------------
 * 共通ヘルパー
 * ------------------------------------------------------------ */
function getSS() {
  const ssId = PropertiesService.getScriptProperties().getProperty("SPREADSHEET_ID");
  return SpreadsheetApp.openById(ssId);
}
function getSheet(name) {
  return getSS().getSheetByName(name);
}
function getFolder() {
  const folderId = PropertiesService.getScriptProperties().getProperty("ROOT_FOLDER_ID");
  return DriveApp.getFolderById(folderId);
}
function jsonOut(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj)).setMimeType(ContentService.MimeType.JSON);
}
function sheetToObjects(sheet) {
  const values = sheet.getDataRange().getValues();
  if (values.length < 2) return [];
  const headers = values[0];
  return values.slice(1).filter(r => r.some(c => c !== "")).map(row => {
    const obj = {};
    headers.forEach((h, i) => obj[h] = row[i]);
    return obj;
  });
}
function findRowIndexByCol(sheet, colName, value) {
  const values = sheet.getDataRange().getValues();
  const headers = values[0];
  const colIdx = headers.indexOf(colName);
  for (let i = 1; i < values.length; i++) {
    if (String(values[i][colIdx]) === String(value)) return i + 1;
  }
  return -1;
}
function rowFromObject(headers, obj) {
  return headers.map(h => (obj[h] !== undefined ? obj[h] : ""));
}
function safeParse(str, fallback) {
  try { return str ? JSON.parse(str) : fallback; } catch (e) { return fallback; }
}
function withLock(fn) {
  const lock = LockService.getScriptLock();
  lock.waitLock(15000);
  try {
    return fn();
  } finally {
    lock.releaseLock();
  }
}

/* ------------------------------------------------------------
 * 認証（ログイン・セッション確認）
 * ------------------------------------------------------------ */
function loginStaff(username, password) {
  const sheet = getSheet(CONFIG.SHEETS.STAFF);
  const rows = sheetToObjects(sheet);
  const staff = rows.find(r =>
    String(r.username) === String(username) &&
    String(r.password) === String(password) &&
    String(r.active).toString().toUpperCase() !== "FALSE"
  );
  if (!staff) {
    return { ok: false, error: "IDまたはパスワードが正しくありません" };
  }
  const token = Utilities.getUuid();
  const expiresAt = new Date(Date.now() + CONFIG.SESSION_HOURS * 3600 * 1000).toISOString();
  const sessSheet = getSheet(CONFIG.SHEETS.SESSIONS);
  sessSheet.appendRow([token, staff.staffId, staff.name, staff.role, expiresAt]);
  return { ok: true, token, name: staff.name, role: staff.role, staffId: staff.staffId };
}

function logoutStaff(token) {
  const sheet = getSheet(CONFIG.SHEETS.SESSIONS);
  const data = sheet.getDataRange().getValues();
  for (let i = data.length - 1; i >= 1; i--) {
    if (data[i][0] === token) sheet.deleteRow(i + 1);
  }
  return { ok: true };
}

function validateToken(token) {
  if (!token) return null;
  const sheet = getSheet(CONFIG.SHEETS.SESSIONS);
  const rows = sheetToObjects(sheet);
  const sess = rows.find(r => String(r.token) === String(token));
  if (!sess) return null;
  if (new Date(sess.expiresAt).getTime() < Date.now()) return null;
  return { staffId: sess.staffId, name: sess.name, role: sess.role };
}

function logOp(auth, action, targetId, detail) {
  try {
    const sheet = getSheet(CONFIG.SHEETS.LOGS);
    sheet.appendRow([Utilities.getUuid(), new Date().toISOString(), auth.staffId, auth.name, action, targetId || "", detail || ""]);
  } catch (e) {
    // ログ記録の失敗で本処理を止めない
  }
}

/* ------------------------------------------------------------
 * 他システム連携用の署名付きトークン発行
 * ------------------------------------------------------------ */
function computeLinkSig(memberId, exp, secret) {
  const raw = memberId + "|" + exp + "|" + secret;
  const digest = Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256, raw, Utilities.Charset.UTF_8);
  return digest.map(b => ((b < 0 ? b + 256 : b).toString(16)).padStart(2, "0")).join("");
}
function issueLinkToken(memberId) {
  const secret = PropertiesService.getScriptProperties().getProperty("LINK_SECRET");
  if (!secret) return { ok: false, error: "LINK_SECRETが未設定です。setup関数を再実行してください。" };
  const mid = memberId || "";
  const exp = Math.floor(Date.now() / 1000) + 5 * 60; // 5分間有効
  const sig = computeLinkSig(mid, exp, secret);
  return { ok: true, memberId: mid, exp, sig };
}

/* ------------------------------------------------------------
 * GET: 読み取り系（すべてログイン必須）
 * ------------------------------------------------------------ */
function doGet(e) {
  const action = e.parameter.action;
  if (!action) {
    return renderApp();
  }

  const auth = validateToken(e.parameter.token);
  if (!auth) {
    return jsonOut({ ok: false, error: "unauthorized", code: "AUTH" });
  }

  try {
    if (action === "bootstrap") {
      return jsonOut({
        ok: true,
        patients: sheetToObjects(getSheet(CONFIG.SHEETS.PATIENTS)),
        templates: sheetToObjects(getSheet(CONFIG.SHEETS.TEMPLATES)),
        stores: sheetToObjects(getSheet(CONFIG.SHEETS.STORES)),
      });
    }
    if (action === "karte") {
      const memberId = e.parameter.memberId;
      const all = sheetToObjects(getSheet(CONFIG.SHEETS.KARTE));
      const filtered = all.filter(r => String(r.memberId) === String(memberId))
        .map(r => ({ ...r, services: safeParse(r.services, []), images: safeParse(r.images, []) }));
      return jsonOut({ ok: true, entries: filtered });
    }
    return jsonOut({ ok: false, error: "unknown action" });
  } catch (err) {
    return jsonOut({ ok: false, error: String(err) });
  }
}

/* ------------------------------------------------------------
 * アプリ画面（Index.html）を配信 ※現在はGitHub Pages側を使用のため未使用
 * ------------------------------------------------------------ */
function renderApp() {
  const tmpl = HtmlService.createTemplateFromFile("Index");
  return tmpl.evaluate()
    .setTitle("Jump 電子カルテシステム")
    .addMetaTag("viewport", "width=device-width, initial-scale=1.0, maximum-scale=1, user-scalable=no");
}

/* ------------------------------------------------------------
 * POST: 書き込み系 + ログイン
 * ------------------------------------------------------------ */
function doPost(e) {
  let body;
  try {
    body = JSON.parse(e.postData.contents);
  } catch (err) {
    return jsonOut({ ok: false, error: "invalid body" });
  }

  const action = body.action;
  const p = body.payload || {};

  // ログインだけは未認証でも呼べる
  if (action === "login") {
    return jsonOut(loginStaff(p.username, p.password));
  }

  const auth = validateToken(body.token);
  if (!auth) {
    return jsonOut({ ok: false, error: "unauthorized", code: "AUTH" });
  }

  if (action === "logout") {
    return jsonOut(logoutStaff(body.token));
  }

  try {
    switch (action) {
      case "issueLinkToken":
        return jsonOut(issueLinkToken(p.memberId));
      case "savePatient":
        logOp(auth, "savePatient", p.memberId, p.name || "");
        return jsonOut(withLock(() => savePatient(p)));
      case "deletePatient":
        logOp(auth, "deletePatient", p.memberId);
        return jsonOut(withLock(() => deletePatient(p)));
      case "saveKarteEntry":
        logOp(auth, "saveKarteEntry", p.memberId, p.date || "");
        return jsonOut(withLock(() => saveKarteEntry(p)));
      case "deleteKarteEntry":
        logOp(auth, "deleteKarteEntry", p.entryId);
        return jsonOut(withLock(() => deleteKarteEntry(p)));
      case "saveTemplate":
        logOp(auth, "saveTemplate", p.templateId || "", p.title || "");
        return jsonOut(withLock(() => saveTemplate(p)));
      case "deleteTemplate":
        logOp(auth, "deleteTemplate", p.templateId);
        return jsonOut(withLock(() => deleteTemplate(p)));
      case "saveStore":
        logOp(auth, "saveStore", p.storeId || "", p.name || "");
        return jsonOut(withLock(() => saveStore(p)));
      case "deleteStore":
        logOp(auth, "deleteStore", p.storeId);
        return jsonOut(withLock(() => deleteStore(p)));
      default:
        return jsonOut({ ok: false, error: "unknown action" });
    }
  } catch (err) {
    return jsonOut({ ok: false, error: String(err) });
  }
}

/* ---------------- 患者 ---------------- */
function savePatient(p) {
  const sheet = getSheet(CONFIG.SHEETS.PATIENTS);
  const headers = sheet.getDataRange().getValues()[0];
  const rowIdx = findRowIndexByCol(sheet, "memberId", p.memberId);
  const obj = {
    memberId: p.memberId, name: p.name || "", birthdate: p.birthdate || "",
    store: p.store || "", notice: p.notice || "",
    createdAt: p.createdAt || new Date().toISOString(),
  };
  if (rowIdx > 0) {
    sheet.getRange(rowIdx, 1, 1, headers.length).setValues([rowFromObject(headers, obj)]);
  } else {
    sheet.appendRow(rowFromObject(headers, obj));
  }
  return { ok: true };
}
function deletePatient(p) {
  const sheet = getSheet(CONFIG.SHEETS.PATIENTS);
  const rowIdx = findRowIndexByCol(sheet, "memberId", p.memberId);
  if (rowIdx > 0) sheet.deleteRow(rowIdx);
  const karteSheet = getSheet(CONFIG.SHEETS.KARTE);
  const values = karteSheet.getDataRange().getValues();
  for (let i = values.length - 1; i >= 1; i--) {
    if (String(values[i][1]) === String(p.memberId)) karteSheet.deleteRow(i + 1);
  }
  return { ok: true };
}

/* ---------------- カルテ記録 ---------------- */
function saveKarteEntry(p) {
  const sheet = getSheet(CONFIG.SHEETS.KARTE);
  const headers = sheet.getDataRange().getValues()[0];

  const imageUrls = (p.images || []).map(img => {
    if (typeof img === "string" && img.indexOf("data:image") === 0) {
      return uploadImageToDrive(img, p.memberId);
    }
    return img;
  });

  const entryId = p.entryId || ("entry_" + Utilities.getUuid().slice(0, 12));
  const now = new Date().toISOString();
  const obj = {
    entryId,
    memberId: p.memberId,
    date: p.date || "",
    services: JSON.stringify(p.services || []),
    freeService: p.freeService || "",
    text: p.text || "",
    images: JSON.stringify(imageUrls),
    createdAt: p.createdAt || now,
    updatedAt: now,
  };

  const rowIdx = findRowIndexByCol(sheet, "entryId", entryId);
  if (rowIdx > 0) {
    sheet.getRange(rowIdx, 1, 1, headers.length).setValues([rowFromObject(headers, obj)]);
  } else {
    sheet.appendRow(rowFromObject(headers, obj));
  }
  return { ok: true, entryId, images: imageUrls };
}
function deleteKarteEntry(p) {
  const sheet = getSheet(CONFIG.SHEETS.KARTE);
  const rowIdx = findRowIndexByCol(sheet, "entryId", p.entryId);
  if (rowIdx > 0) sheet.deleteRow(rowIdx);
  return { ok: true };
}
function uploadImageToDrive(dataUrl, memberId) {
  const matches = dataUrl.match(/^data:(image\/\w+);base64,(.*)$/);
  if (!matches) return "";
  const mimeType = matches[1];
  const base64 = matches[2];
  const bytes = Utilities.base64Decode(base64);
  const ext = mimeType.split("/")[1] || "jpg";
  const blob = Utilities.newBlob(bytes, mimeType, `karte_${memberId}_${Date.now()}.${ext}`);

  const root = getFolder();
  let sub;
  const it = root.getFoldersByName(String(memberId));
  sub = it.hasNext() ? it.next() : root.createFolder(String(memberId));

  const file = sub.createFile(blob);
  file.setSharing(DriveApp.Access.ANYONE_WITH_LINK, DriveApp.Permission.VIEW);
  return `https://lh3.googleusercontent.com/d/${file.getId()}=w1000`;
}

/* ---------------- 見本テキスト ---------------- */
function saveTemplate(p) {
  const sheet = getSheet(CONFIG.SHEETS.TEMPLATES);
  const headers = sheet.getDataRange().getValues()[0];
  const templateId = p.templateId || ("tmpl_" + Utilities.getUuid().slice(0, 8));
  const obj = { templateId, title: p.title || "", text: p.text || "" };
  const rowIdx = findRowIndexByCol(sheet, "templateId", templateId);
  if (rowIdx > 0) {
    sheet.getRange(rowIdx, 1, 1, headers.length).setValues([rowFromObject(headers, obj)]);
  } else {
    sheet.appendRow(rowFromObject(headers, obj));
  }
  return { ok: true, templateId };
}
function deleteTemplate(p) {
  const sheet = getSheet(CONFIG.SHEETS.TEMPLATES);
  const rowIdx = findRowIndexByCol(sheet, "templateId", p.templateId);
  if (rowIdx > 0) sheet.deleteRow(rowIdx);
  return { ok: true };
}

/* ---------------- 店舗 ---------------- */
function saveStore(p) {
  const sheet = getSheet(CONFIG.SHEETS.STORES);
  const headers = sheet.getDataRange().getValues()[0];
  const storeId = p.storeId || ("store_" + Utilities.getUuid().slice(0, 8));
  const obj = { storeId, name: p.name || "" };
  const rowIdx = findRowIndexByCol(sheet, "storeId", storeId);
  if (rowIdx > 0) {
    sheet.getRange(rowIdx, 1, 1, headers.length).setValues([rowFromObject(headers, obj)]);
  } else {
    sheet.appendRow(rowFromObject(headers, obj));
  }
  return { ok: true, storeId };
}
function deleteStore(p) {
  const sheet = getSheet(CONFIG.SHEETS.STORES);
  const rowIdx = findRowIndexByCol(sheet, "storeId", p.storeId);
  if (rowIdx > 0) sheet.deleteRow(rowIdx);
  return { ok: true };
}
